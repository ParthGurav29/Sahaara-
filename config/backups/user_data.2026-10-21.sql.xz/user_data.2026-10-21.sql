BEGIN TRANSACTION;
CREATE TABLE admin_flags (
    key TEXT NOT NULL PRIMARY KEY,
    on_flag INTEGER NOT NULL DEFAULT 1,
    value TEXT NOT NULL DEFAULT '',
    age_rating_metron_name TEXT,
    updated_at TEXT
);
INSERT INTO "admin_flags" VALUES('AR',1,'','Everyone','2026-10-20T18:12:41.674525+00:00');
INSERT INTO "admin_flags" VALUES('AA',1,'','Adult','2026-10-20T18:12:41.697939+00:00');
INSERT INTO "admin_flags" VALUES('MP',1,'100',NULL,'2026-10-20T18:12:42.506100+00:00');
INSERT INTO "admin_flags" VALUES('CM',1,'10',NULL,'2026-10-20T18:12:42.506774+00:00');
INSERT INTO "admin_flags" VALUES('AK',1,'0JNe6hklTgaY3REa1ZSjcw',NULL,'2026-10-20T18:12:45.216968+00:00');
INSERT INTO "admin_flags" VALUES('AU',1,'',NULL,'2026-10-20T18:12:45.220052+00:00');
INSERT INTO "admin_flags" VALUES('BT',1,'',NULL,'2026-10-20T18:12:45.222978+00:00');
INSERT INTO "admin_flags" VALUES('FV',1,'',NULL,'2026-10-20T18:12:45.226664+00:00');
INSERT INTO "admin_flags" VALUES('IM',1,'',NULL,'2026-10-20T18:12:45.229456+00:00');
INSERT INTO "admin_flags" VALUES('LI',1,'',NULL,'2026-10-20T18:12:45.232370+00:00');
INSERT INTO "admin_flags" VALUES('NU',1,'',NULL,'2026-10-20T18:12:45.236337+00:00');
INSERT INTO "admin_flags" VALUES('RG',1,'',NULL,'2026-10-20T18:12:45.239236+00:00');
INSERT INTO "admin_flags" VALUES('RV',0,'',NULL,'2026-10-20T18:12:45.242302+00:00');
INSERT INTO "admin_flags" VALUES('ST',1,'',NULL,'2026-10-20T18:12:45.245399+00:00');
CREATE TABLE bookmarks (
    username TEXT NOT NULL,
    comic_path TEXT NOT NULL,
    page INTEGER,
    finished INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT,
    PRIMARY KEY (username, comic_path)
);
CREATE TABLE favorites (
    username TEXT NOT NULL,
    collection TEXT NOT NULL,
    identifier_json TEXT NOT NULL,
    updated_at TEXT,
    PRIMARY KEY (username, collection, identifier_json)
);
CREATE TABLE groups (
    name TEXT NOT NULL PRIMARY KEY,
    permissions TEXT NOT NULL DEFAULT '[]',  -- JSON list of "app_label.codename"
    exclude INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT
);
CREATE TABLE libraries (
    path TEXT NOT NULL PRIMARY KEY,
    events INTEGER NOT NULL DEFAULT 1,
    poll INTEGER NOT NULL DEFAULT 1,
    poll_every TEXT,                              -- ISO 8601 duration
    last_poll TEXT,
    updated_at TEXT
);
CREATE TABLE library_groups (
    library_path TEXT NOT NULL,
    group_name TEXT NOT NULL,
    PRIMARY KEY (library_path, group_name)
);
CREATE TABLE schema_version (
    version INTEGER NOT NULL PRIMARY KEY
);
INSERT INTO "schema_version" VALUES(1);
CREATE TABLE settings_browser (
    username TEXT NOT NULL,
    client TEXT NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    top_collection TEXT NOT NULL DEFAULT '',
    order_by TEXT NOT NULL DEFAULT '',
    order_reverse INTEGER NOT NULL DEFAULT 0,
    order_extra_keys TEXT NOT NULL DEFAULT '[]',
    collection_order_memory TEXT NOT NULL DEFAULT '{}',
    search TEXT NOT NULL DEFAULT '',
    twenty_four_hour_time INTEGER NOT NULL DEFAULT 0,
    always_show_filename INTEGER NOT NULL DEFAULT 0,
    view_mode TEXT NOT NULL DEFAULT '',
    table_columns TEXT NOT NULL DEFAULT '{}',
    table_cover_size TEXT NOT NULL DEFAULT '',
    show_p INTEGER NOT NULL DEFAULT 1,
    show_i INTEGER NOT NULL DEFAULT 0,
    show_s INTEGER NOT NULL DEFAULT 1,
    show_v INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT,
    PRIMARY KEY (username, client, name)
);
CREATE TABLE settings_defaults (
    pk INTEGER NOT NULL PRIMARY KEY DEFAULT 1,
    top_collection TEXT NOT NULL DEFAULT 'publishers',
    show_publishers INTEGER NOT NULL DEFAULT 1,
    show_imprints INTEGER NOT NULL DEFAULT 0,
    show_series INTEGER NOT NULL DEFAULT 1,
    show_volumes INTEGER NOT NULL DEFAULT 0,
    order_by TEXT NOT NULL DEFAULT '',
    order_reverse INTEGER NOT NULL DEFAULT 0,
    view_mode TEXT NOT NULL DEFAULT 'cover',
    twenty_four_hour_time INTEGER NOT NULL DEFAULT 0,
    always_show_filename INTEGER NOT NULL DEFAULT 0,
    bookmark TEXT NOT NULL DEFAULT '',
    table_columns TEXT NOT NULL DEFAULT '{}',
    fit_to TEXT NOT NULL DEFAULT 'W',
    reading_direction TEXT NOT NULL DEFAULT 'ltr',
    two_pages INTEGER NOT NULL DEFAULT 0,
    page_transition INTEGER NOT NULL DEFAULT 1,
    cache_book INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT
);
INSERT INTO "settings_defaults" VALUES(1,'publishers',1,0,1,0,'',0,'cover',0,0,'','{}','W','ltr',0,1,0,'2026-10-20T18:12:44.281120+00:00');
CREATE TABLE settings_filters (
    username TEXT NOT NULL,
    client TEXT NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    bookmark TEXT NOT NULL DEFAULT '',
    favorite INTEGER NOT NULL DEFAULT 0,
    age_rating_metron TEXT NOT NULL DEFAULT '[]',
    age_rating_tagged TEXT NOT NULL DEFAULT '[]',
    characters TEXT NOT NULL DEFAULT '[]',
    community_rating TEXT NOT NULL DEFAULT '[]',
    country TEXT NOT NULL DEFAULT '[]',
    credits TEXT NOT NULL DEFAULT '[]',
    decade TEXT NOT NULL DEFAULT '[]',
    file_type TEXT NOT NULL DEFAULT '[]',
    genres TEXT NOT NULL DEFAULT '[]',
    identifier_source TEXT NOT NULL DEFAULT '[]',
    language TEXT NOT NULL DEFAULT '[]',
    locations TEXT NOT NULL DEFAULT '[]',
    monochrome TEXT NOT NULL DEFAULT '[]',
    original_format TEXT NOT NULL DEFAULT '[]',
    reading_direction TEXT NOT NULL DEFAULT '[]',
    reprints TEXT NOT NULL DEFAULT '[]',
    series_groups TEXT NOT NULL DEFAULT '[]',
    stories TEXT NOT NULL DEFAULT '[]',
    story_arcs TEXT NOT NULL DEFAULT '[]',
    tagger TEXT NOT NULL DEFAULT '[]',
    tags TEXT NOT NULL DEFAULT '[]',
    teams TEXT NOT NULL DEFAULT '[]',
    universes TEXT NOT NULL DEFAULT '[]',
    year TEXT NOT NULL DEFAULT '[]',
    PRIMARY KEY (username, client, name)
);
CREATE TABLE settings_last_route (
    username TEXT NOT NULL,
    client TEXT NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    collection TEXT NOT NULL DEFAULT 'root',
    pks_json TEXT NOT NULL DEFAULT '[]',
    page INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (username, client, name)
);
CREATE TABLE tagging_defaults (
    pk INTEGER NOT NULL PRIMARY KEY DEFAULT 1,
    default_formats TEXT NOT NULL DEFAULT '[]',
    delete_original INTEGER NOT NULL DEFAULT 0,
    default_match_mode TEXT NOT NULL DEFAULT 'auto',
    default_prompts_mode TEXT NOT NULL DEFAULT 'ask',
    default_sources TEXT NOT NULL DEFAULT '[]',
    metron_key TEXT NOT NULL DEFAULT '',
    metron_user TEXT NOT NULL DEFAULT '',
    metron_password TEXT NOT NULL DEFAULT '',
    comicvine_key TEXT NOT NULL DEFAULT '',
    comicvine_url TEXT NOT NULL DEFAULT '',
    updated_at TEXT
);
INSERT INTO "tagging_defaults" VALUES(1,'["COMIC_INFO","METRON_INFO"]',1,'auto','ask','["metron","comicvine"]','','','','','','2026-10-20T18:12:42.272676+00:00');
CREATE TABLE timestamps (
    key TEXT NOT NULL PRIMARY KEY,
    value TEXT NOT NULL DEFAULT '',
    updated_at TEXT
);
INSERT INTO "timestamps" VALUES('VR','2.5.5','2026-10-20T18:30:00.503736+00:00');
INSERT INTO "timestamps" VALUES('JA','','2026-10-20T18:30:00.067558+00:00');
INSERT INTO "timestamps" VALUES('TS','848ebe60-b01a-444e-bed8-f0ed08e356fa','2026-10-20T18:12:53.915923+00:00');
INSERT INTO "timestamps" VALUES('FI','','2026-10-20T18:12:45.259529+00:00');
CREATE TABLE user_groups (
    username TEXT NOT NULL,
    group_name TEXT NOT NULL,
    PRIMARY KEY (username, group_name)
);
CREATE TABLE users (
    username TEXT NOT NULL PRIMARY KEY,
    password TEXT NOT NULL DEFAULT '',
    email TEXT NOT NULL DEFAULT '',
    first_name TEXT NOT NULL DEFAULT '',
    last_name TEXT NOT NULL DEFAULT '',
    is_staff INTEGER NOT NULL DEFAULT 0,
    is_superuser INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    date_joined TEXT,
    last_login TEXT,
    age_rating_metron_name TEXT,
    updated_at TEXT
);
INSERT INTO "users" VALUES('admin','pbkdf2_sha256$1500000$zLAlBOQiGY1En3jR0Ty4vS$UPfIS+Q0cqOqPrJ82OzzuuM6M9OOmv3jhEfbXED2w2Q=','','','',1,1,1,'2026-10-20T18:12:44.933878+00:00',NULL,NULL,NULL);
COMMIT;
